# Please do not delete this file. It determine plugin for rys gems.
# Later it could be used for rys settings.
